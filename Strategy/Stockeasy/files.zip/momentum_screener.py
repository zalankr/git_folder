#!/usr/bin/env python3
"""
MOMENTUM 전략 클론 스크리너
== "추세추종 모멘텀, 상승 초입 포착" ==

로직:
  1. MTT(Minervini Trend Template) 8조건 충족
  2. RS (63일 상대강도, KOSPI 대비) 상위
  3. 거래대금·시총 필터
  4. '상승 초입' 포착을 위해 52주 신고가 대비 5~25% 범위로 제한
     (이미 돌파한 종목은 PEAK 전략에서 포착)

출력: /var/autobot/TR_KRTR/momentum_clone_target.json
"""
import os
import json
import time
import numpy as np
import pandas as pd
from datetime import datetime, timedelta
from screener_common import (
    get_krx_universe, filter_tradable, download_ohlcv, download_index,
    get_fundamentals, get_market_cap, apply_basic_filter,
)

# ---------------- MTT 8조건 ----------------
def check_mtt(df: pd.DataFrame) -> dict:
    """
    Minervini Trend Template 8조건 체크.
    df: 최근 1년+ OHLCV (Close 기준)
    반환: {'pass': bool, 'score': 0~8, 'details': {...}}
    """
    if len(df) < 220:  # 200일 MA 필요
        return {"pass": False, "score": 0, "details": {}}

    close = df["Close"]
    ma50  = close.rolling(50).mean()
    ma150 = close.rolling(150).mean()
    ma200 = close.rolling(200).mean()

    p      = close.iloc[-1]
    m50    = ma50.iloc[-1]
    m150   = ma150.iloc[-1]
    m200   = ma200.iloc[-1]
    # 200일선 1개월(22일) 전 대비 상승
    m200_1m_ago = ma200.iloc[-22] if len(ma200.dropna()) >= 22 else m200

    low_52w  = close.iloc[-252:].min() if len(close) >= 252 else close.min()
    high_52w = close.iloc[-252:].max() if len(close) >= 252 else close.max()

    cond = {
        "c1_above_150_200": p > m150 and p > m200,
        "c2_150_above_200": m150 > m200,
        "c3_200_rising":    m200 > m200_1m_ago,
        "c4_50_above_150_200": m50 > m150 and m50 > m200,
        "c5_above_50":      p > m50,
        "c6_30pct_above_low": p >= low_52w * 1.30,
        "c7_within_25pct_high": p >= high_52w * 0.75,
    }
    # c8 (RS 70+)은 외부에서 별도 계산
    score = sum(cond.values())
    return {"pass": score == 7, "score": score, "details": cond,
            "p": p, "low_52w": low_52w, "high_52w": high_52w}


# ---------------- RS 상대강도 ----------------
def calc_rs(stock_df: pd.DataFrame, bench_df: pd.DataFrame, period: int = 63) -> float:
    """
    상대강도 = (종목 N일 수익률) - (벤치 N일 수익률)
    양수일수록 벤치마크보다 강함.
    """
    if len(stock_df) < period + 1 or len(bench_df) < period + 1:
        return np.nan
    s_ret = stock_df["Close"].iloc[-1] / stock_df["Close"].iloc[-period-1] - 1
    b_ret = bench_df["Close"].iloc[-1] / bench_df["Close"].iloc[-period-1] - 1
    return (s_ret - b_ret) * 100


def rank_to_percentile(values: pd.Series) -> pd.Series:
    """백분위 랭킹 (0~100). 높을수록 강함."""
    return values.rank(pct=True) * 100


# ---------------- 메인 스크리너 ----------------
def screen_momentum(top_n: int = 30) -> list:
    today = datetime.now()
    end   = today.strftime("%Y%m%d")
    start = (today - timedelta(days=400)).strftime("%Y%m%d")

    print("[1/5] 유니버스 로딩...")
    uni = get_krx_universe(end)
    uni = filter_tradable(uni, end)
    print(f"  유니버스 {len(uni)}종목")

    print("[2/5] 시총/거래대금 필터...")
    cap = get_market_cap(end)
    fund = get_fundamentals(end)
    uni = apply_basic_filter(uni, fund, cap)
    print(f"  1차 필터 통과: {len(uni)}종목")

    print("[3/5] 벤치마크(KOSPI) 다운로드...")
    bench = download_index("1001", start, end)

    print(f"[4/5] 종목별 OHLCV 다운로드 & MTT 체크 (최대 10분 소요)...")
    results = []
    for i, row in uni.iterrows():
        code, name = row["code"], row["name"]
        df = download_ohlcv(code, start, end)
        if df.empty or len(df) < 220:
            continue
        mtt = check_mtt(df)
        if mtt["score"] < 6:  # 느슨한 기준 (6/7 이상) - 이후 RS로 재랭킹
            continue
        # '상승 초입' 필터: 52주 고점의 75~95% 범위 (이미 돌파한 건 제외)
        p, h = mtt["p"], mtt["high_52w"]
        if not (0.75 <= p / h <= 0.98):
            continue
        rs_63  = calc_rs(df, bench, 63)   # 3개월 RS
        rs_126 = calc_rs(df, bench, 126)  # 6개월 RS
        if np.isnan(rs_63):
            continue
        # 거래대금 20일 평균
        vol20 = df["Value"].iloc[-20:].mean() if len(df) >= 20 else 0
        if vol20 < 1_000_000_000:  # 10억 미만 제외
            continue
        results.append({
            "code": code, "name": name,
            "mtt_score": mtt["score"],
            "rs_63": round(rs_63, 2),
            "rs_126": round(rs_126, 2) if not np.isnan(rs_126) else None,
            "price": int(mtt["p"]),
            "dist_to_52w_high_pct": round((p/h - 1) * 100, 2),
            "vol20_bn": round(vol20 / 1e8, 1),  # 억원
        })
        if (i + 1) % 100 == 0:
            print(f"    진행 {i+1}/{len(uni)}, 현재 통과 {len(results)}종목")
        time.sleep(0.05)

    print(f"[5/5] RS 랭킹 & 최종 선정...")
    if not results:
        print("조건 충족 종목 없음")
        return []

    rdf = pd.DataFrame(results)
    # RS 63/126 평균을 최종 스코어로
    rdf["rs_combined"] = rdf[["rs_63", "rs_126"]].mean(axis=1)
    rdf["rs_pct"] = rank_to_percentile(rdf["rs_combined"])
    # RS 70 이상만 (MTT c8 조건)
    rdf = rdf[rdf["rs_pct"] >= 70]
    # 최종: MTT 스코어 + RS 합산 랭킹
    rdf["final_score"] = rdf["mtt_score"] * 10 + rdf["rs_pct"]
    rdf = rdf.sort_values("final_score", ascending=False).head(top_n)

    print(f"  최종 선정 {len(rdf)}종목")
    return rdf.to_dict(orient="records")


if __name__ == "__main__":
    picks = screen_momentum(top_n=30)
    out = {
        "strategy": "MOMENTUM_CLONE",
        "updated_at": datetime.now().isoformat(),
        "count": len(picks),
        "picks": picks,
    }
    path = "/var/autobot/TR_KRTR/momentum_clone_target.json"
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, "w", encoding="utf-8") as f:
        json.dump(out, f, ensure_ascii=False, indent=2)
    print(f"\n저장: {path}")
    for p in picks[:10]:
        print(f"  {p['name']}({p['code']}) MTT={p['mtt_score']}/7 "
              f"RS63={p['rs_63']:+.1f}% 고점까지{p['dist_to_52w_high_pct']:+.1f}%")
