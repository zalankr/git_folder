#!/usr/bin/env python3
"""
StockEasy 클론 스크리너 공통 유틸
- 유니버스 로딩 (KOSPI+KOSDAQ)
- 가격/거래량 로드 (pykrx 우선, FDR fallback)
- 재무지표 로드 (pykrx)
- 1차 필터 (거래정지/관리종목/스팩/우선주/ETF 제외)

필수 설치:
  pip install pykrx finance-datareader pandas numpy
"""
import time
import numpy as np
import pandas as pd
from datetime import datetime, timedelta
from pykrx import stock as krx
import FinanceDataReader as fdr

# ---------------- 유니버스 ----------------
def get_krx_universe(date: str = None) -> pd.DataFrame:
    """
    KOSPI+KOSDAQ 전체 종목. 다음을 제외:
      - 우선주 (종목명 끝자리 '우' 또는 코드 말미 5,7)
      - 스팩 ('스팩' 포함)
      - ETF/ETN/리츠 (pykrx는 일반주식만 반환)
    반환: DataFrame[code, name, market]
    """
    if date is None:
        date = datetime.now().strftime("%Y%m%d")
    rows = []
    for mkt in ("KOSPI", "KOSDAQ"):
        tickers = krx.get_market_ticker_list(date, market=mkt)
        for t in tickers:
            name = krx.get_market_ticker_name(t)
            if name.endswith("우") or name.endswith("우B") or "스팩" in name:
                continue
            # 우선주 코드 패턴 (끝자리 5/7)
            if t[-1] in ("5", "7"):
                continue
            rows.append({"code": t, "name": name, "market": mkt})
        time.sleep(0.2)
    return pd.DataFrame(rows)


def filter_tradable(df: pd.DataFrame, date: str = None) -> pd.DataFrame:
    """거래정지/관리종목 제외"""
    if date is None:
        date = datetime.now().strftime("%Y%m%d")
    # 관리종목 리스트
    admin = set()
    try:
        admin_df = krx.get_market_trading_halt()  # 거래정지
        admin = set(admin_df.index.tolist()) if admin_df is not None else set()
    except Exception:
        pass
    return df[~df["code"].isin(admin)].reset_index(drop=True)


# ---------------- 가격 다운로드 ----------------
def download_ohlcv(code: str, start: str, end: str, retry: int = 2) -> pd.DataFrame:
    """
    단일 종목 일봉 OHLCV
    - 1차: pykrx (안정적, 거래량 정확)
    - 2차: FDR (pykrx 실패 시)
    반환 컬럼: Open, High, Low, Close, Volume, Value (거래대금)
    """
    for _ in range(retry):
        try:
            df = krx.get_market_ohlcv(start, end, code)
            if df is not None and not df.empty:
                df = df.rename(columns={
                    "시가": "Open", "고가": "High", "저가": "Low",
                    "종가": "Close", "거래량": "Volume", "거래대금": "Value"
                })
                return df[["Open", "High", "Low", "Close", "Volume", "Value"]]
        except Exception:
            time.sleep(0.3)
    # FDR fallback
    try:
        df = fdr.DataReader(code, start, end)
        if df is not None and not df.empty:
            df["Value"] = df["Close"] * df["Volume"]
            return df[["Open", "High", "Low", "Close", "Volume", "Value"]]
    except Exception:
        pass
    return pd.DataFrame()


def download_index(index_code: str, start: str, end: str) -> pd.DataFrame:
    """
    지수 OHLC. index_code: '1001'(KOSPI), '2001'(KOSDAQ)
    """
    try:
        df = krx.get_index_ohlcv(start, end, index_code)
        if df is not None and not df.empty:
            return df.rename(columns={"종가": "Close"})[["Close"]]
    except Exception:
        pass
    return pd.DataFrame()


# ---------------- 재무지표 ----------------
def get_fundamentals(date: str = None) -> pd.DataFrame:
    """
    전 종목 PER/PBR/EPS/BPS/DIV/DPS (pykrx).
    ROE는 기본 미제공 → PBR/PER로 역산: ROE ≈ PBR / PER
    반환 index=code, columns=[PER, PBR, EPS, BPS, DIV, DPS]
    """
    if date is None:
        date = datetime.now().strftime("%Y%m%d")
    frames = []
    for mkt in ("KOSPI", "KOSDAQ"):
        try:
            f = krx.get_market_fundamental(date, market=mkt)
            frames.append(f)
        except Exception:
            pass
        time.sleep(0.2)
    if not frames:
        return pd.DataFrame()
    df = pd.concat(frames)
    # ROE 역산: PBR/PER (PER>0, PBR>0일 때만)
    df["ROE_est"] = np.where(
        (df["PER"] > 0) & (df["PBR"] > 0),
        df["PBR"] / df["PER"] * 100,
        np.nan
    )
    return df


def get_market_cap(date: str = None) -> pd.DataFrame:
    """시가총액/상장주식수/거래대금. index=code"""
    if date is None:
        date = datetime.now().strftime("%Y%m%d")
    frames = []
    for mkt in ("KOSPI", "KOSDAQ"):
        try:
            f = krx.get_market_cap(date, market=mkt)
            frames.append(f)
        except Exception:
            pass
        time.sleep(0.2)
    return pd.concat(frames) if frames else pd.DataFrame()


# ---------------- 공통 스크리닝 필터 ----------------
def apply_basic_filter(
    df: pd.DataFrame,
    fund: pd.DataFrame,
    cap: pd.DataFrame,
    min_mcap: float = 50_000_000_000,      # 500억 이상
    min_value_20d: float = 1_000_000_000,  # 20일 평균 거래대금 10억 이상
) -> pd.DataFrame:
    """시총·거래대금 하한 적용"""
    merged = df.merge(cap[["시가총액"]], left_on="code", right_index=True, how="left")
    merged = merged[merged["시가총액"] >= min_mcap]
    return merged.reset_index(drop=True)
