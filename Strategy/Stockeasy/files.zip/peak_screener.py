#!/usr/bin/env python3
"""
PEAK 전략 클론 스크리너
== "52주 신고가 돌파 + 강한 상승 모멘텀" ==

로직:
  1. 당일 종가가 직전 250거래일 최고가를 '신규 돌파' (ATH_breakout)
     - 또는 52주 고점의 99.5% 이상 근접 + 당일 신고가 갱신
  2. 거래량 급증: 당일 거래량 ≥ 20일 평균의 1.5배
  3. 거래대금 하한: 20일 평균 30억 이상 (PEAK는 유동성 중요)
  4. MA50 > MA150 (단기추세 양호)
  5. 돌파 후 과열 방지: 돌파일 ± 5거래일 이내만 채택 (초기 돌파만)

출력: /var/autobot/TR_KRTR/peak_clone_target.json
"""
import os
import json
import time
import numpy as np
import pandas as pd
from datetime import datetime, timedelta
from screener_common import (
    get_krx_universe, filter_tradable, download_ohlcv,
    get_market_cap, apply_basic_filter,
)


def check_peak_breakout(df: pd.DataFrame,
                        lookback: int = 250,
                        recent_days: int = 5,
                        vol_mult: float = 1.5) -> dict:
    """
    52주 신고가 돌파 판정.
    
    반환: {'pass', 'breakout_date', 'breakout_ratio', 'vol_ratio', 'score'}
    """
    if len(df) < lookback + 5:
        return {"pass": False}

    close = df["Close"]
    high  = df["High"]
    vol   = df["Volume"]
    val   = df["Value"]

    # 최근 recent_days 내에 52주 신고가를 갱신했는가?
    # 각 날짜 i에서 (i 제외한) 직전 lookback일의 최고 종가 vs 해당일 종가
    pass_flag = False
    breakout_info = None
    for i in range(len(df) - recent_days, len(df)):
        if i - lookback < 0:
            continue
        prior_high = close.iloc[i - lookback:i].max()
        today_close = close.iloc[i]
        today_high  = high.iloc[i]
        if today_close > prior_high * 1.001 and today_high > prior_high:
            # 거래량 급증 체크
            avg_vol20 = vol.iloc[i-20:i].mean()
            vol_ratio = vol.iloc[i] / avg_vol20 if avg_vol20 > 0 else 0
            if vol_ratio >= vol_mult:
                pass_flag = True
                breakout_info = {
                    "breakout_date": df.index[i].strftime("%Y-%m-%d"),
                    "breakout_price": int(today_close),
                    "prior_high": int(prior_high),
                    "breakout_ratio": round(today_close / prior_high - 1, 4),
                    "vol_ratio": round(vol_ratio, 2),
                    "days_since_breakout": len(df) - 1 - i,
                }
                break  # 첫 돌파일만 기록

    if not pass_flag:
        return {"pass": False}

    # 추가: MA50 > MA150 (단기 추세)
    ma50  = close.rolling(50).mean().iloc[-1]
    ma150 = close.rolling(150).mean().iloc[-1] if len(close) >= 150 else np.nan

    ma_ok = (not np.isnan(ma150)) and (ma50 > ma150)

    # 과열 방지: 돌파 후 상승률이 과하면 제외 (15% 넘으면 추격매수 위험)
    p_now = close.iloc[-1]
    run_up = p_now / breakout_info["breakout_price"] - 1

    breakout_info.update({
        "ma_ok": ma_ok,
        "current_price": int(p_now),
        "run_up_pct": round(run_up * 100, 2),
    })

    final_pass = ma_ok and run_up <= 0.15
    breakout_info["pass"] = final_pass
    # 점수: 거래량비율 + (돌파 초기일수록 고점수)
    breakout_info["score"] = (
        breakout_info["vol_ratio"] * 10 +
        max(0, 5 - breakout_info["days_since_breakout"]) * 5 -
        run_up * 100
    )
    return breakout_info


def screen_peak(top_n: int = 25) -> list:
    today = datetime.now()
    end   = today.strftime("%Y%m%d")
    start = (today - timedelta(days=400)).strftime("%Y%m%d")

    print("[1/4] 유니버스 로딩...")
    uni = get_krx_universe(end)
    uni = filter_tradable(uni, end)

    print("[2/4] 시총 필터...")
    cap = get_market_cap(end)
    uni = apply_basic_filter(uni, None, cap, min_mcap=100_000_000_000)  # PEAK는 시총 1000억+
    print(f"  1차 통과: {len(uni)}종목")

    print("[3/4] 돌파 스캔...")
    results = []
    for i, row in uni.iterrows():
        code, name = row["code"], row["name"]
        df = download_ohlcv(code, start, end)
        if df.empty:
            continue
        r = check_peak_breakout(df)
        if not r.get("pass"):
            continue
        # 거래대금 필터
        val20 = df["Value"].iloc[-20:].mean()
        if val20 < 3_000_000_000:  # 30억
            continue
        r.update({"code": code, "name": name, "value20_bn": round(val20/1e8, 1)})
        results.append(r)
        if (i + 1) % 100 == 0:
            print(f"    진행 {i+1}/{len(uni)}, 현재 통과 {len(results)}종목")
        time.sleep(0.05)

    print(f"[4/4] 스코어 랭킹 (상위 {top_n})...")
    if not results:
        print("조건 충족 종목 없음")
        return []

    rdf = pd.DataFrame(results).sort_values("score", ascending=False).head(top_n)
    return rdf.to_dict(orient="records")


if __name__ == "__main__":
    picks = screen_peak(top_n=25)
    out = {
        "strategy": "PEAK_CLONE",
        "updated_at": datetime.now().isoformat(),
        "count": len(picks),
        "picks": picks,
    }
    path = "/var/autobot/TR_KRTR/peak_clone_target.json"
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, "w", encoding="utf-8") as f:
        json.dump(out, f, ensure_ascii=False, indent=2)
    print(f"\n저장: {path}")
    for p in picks[:10]:
        print(f"  {p['name']}({p['code']}) 돌파일 {p['breakout_date']} "
              f"거래량x{p['vol_ratio']} 후행{p['days_since_breakout']}일 "
              f"상승{p['run_up_pct']:+.1f}%")
