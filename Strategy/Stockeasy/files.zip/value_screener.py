#!/usr/bin/env python3
"""
VALUE 전략 클론 스크리너
== "저평가 밸류에이션 기반 종목 선별" ==

로직:
  1. PER > 0 (흑자), PBR > 0
  2. 복합 밸류 스코어 (낮을수록 저평가):
     - PER 백분위 (낮을수록 좋음)
     - PBR 백분위 (낮을수록 좋음)
     - ROE_est 백분위 (높을수록 좋음) ← 역방향
  3. 모멘텀 필터: 최근 3개월 -20% 이하는 제외 (가치함정 회피)
  4. 시총 2000억 이상, 거래대금 10억 이상
  5. 배당수익률 보너스

참고: PBR = ROE × PER 관계식에서, 같은 PBR이면 ROE가 높은 기업이 PER이 낮음
     → 저PER+저PBR만 뽑으면 ROE 낮은 가치함정 섞임
     → ROE_est(=PBR/PER*100) 최소 하한 설정

출력: /var/autobot/TR_KRTR/value_clone_target.json
"""
import os
import json
import time
import numpy as np
import pandas as pd
from datetime import datetime, timedelta
from screener_common import (
    get_krx_universe, filter_tradable, download_ohlcv,
    get_fundamentals, get_market_cap, apply_basic_filter,
)


def calc_3m_return(code: str, end: str, start: str) -> float:
    df = download_ohlcv(code, start, end)
    if df.empty or len(df) < 60:
        return np.nan
    return df["Close"].iloc[-1] / df["Close"].iloc[-60] - 1


def screen_value(top_n: int = 15) -> list:
    today = datetime.now()
    end   = today.strftime("%Y%m%d")
    start = (today - timedelta(days=120)).strftime("%Y%m%d")

    print("[1/5] 유니버스 + 펀더멘털...")
    uni  = get_krx_universe(end)
    uni  = filter_tradable(uni, end)
    fund = get_fundamentals(end)
    cap  = get_market_cap(end)

    # 병합
    df = uni.merge(fund, left_on="code", right_index=True, how="inner")
    df = df.merge(cap[["시가총액"]], left_on="code", right_index=True, how="inner")
    print(f"  병합 후: {len(df)}종목")

    print("[2/5] 기본 필터 (흑자·시총·PER/PBR)...")
    before = len(df)
    df = df[
        (df["PER"] > 0) & (df["PER"] < 50) &     # 흑자 & 극단고평가 제외
        (df["PBR"] > 0.2) & (df["PBR"] < 5) &    # 극단치 제외
        (df["시가총액"] >= 200_000_000_000) &    # 2000억 이상
        (df["ROE_est"] >= 5)                     # ROE 5% 이상 (가치함정 방지)
    ]
    print(f"  {before} → {len(df)}종목")

    print("[3/5] 모멘텀 필터 (최근 3개월 -20% 이상만)...")
    keep = []
    for i, row in df.iterrows():
        r3 = calc_3m_return(row["code"], end, start)
        if np.isnan(r3) or r3 >= -0.20:
            keep.append((row["code"], r3))
        if len(keep) % 100 == 0 and keep:
            print(f"    진행 {len(keep)}종목 통과")
        time.sleep(0.05)
    ret_map = dict(keep)
    df = df[df["code"].isin(ret_map.keys())]
    df["ret_3m"] = df["code"].map(ret_map)
    print(f"  모멘텀 필터 후: {len(df)}종목")

    print("[4/5] 복합 밸류 스코어 계산...")
    # 백분위 (낮을수록 저평가, 높을수록 우량)
    df["per_pct"]   = df["PER"].rank(pct=True) * 100   # 낮을수록 좋음
    df["pbr_pct"]   = df["PBR"].rank(pct=True) * 100   # 낮을수록 좋음
    df["roe_pct"]   = df["ROE_est"].rank(pct=True) * 100  # 높을수록 좋음
    df["div_pct"]   = df["DIV"].fillna(0).rank(pct=True) * 100  # 높을수록 좋음

    # 스코어: (저PER + 저PBR) 가중 + (고ROE + 고배당) 가중
    df["value_score"] = (
        (100 - df["per_pct"]) * 0.30 +
        (100 - df["pbr_pct"]) * 0.30 +
        df["roe_pct"]         * 0.30 +
        df["div_pct"]         * 0.10
    )

    df = df.sort_values("value_score", ascending=False).head(top_n)

    print(f"[5/5] 최종 {len(df)}종목")
    result = []
    for _, r in df.iterrows():
        result.append({
            "code": r["code"],
            "name": r["name"],
            "market": r["market"],
            "PER": round(r["PER"], 2),
            "PBR": round(r["PBR"], 2),
            "ROE_est": round(r["ROE_est"], 2),
            "DIV_pct": round(r["DIV"], 2) if pd.notna(r["DIV"]) else 0,
            "mcap_bn": round(r["시가총액"] / 1e8, 0),  # 억원
            "ret_3m_pct": round(r["ret_3m"] * 100, 2) if pd.notna(r["ret_3m"]) else None,
            "value_score": round(r["value_score"], 2),
        })
    return result


if __name__ == "__main__":
    picks = screen_value(top_n=15)
    out = {
        "strategy": "VALUE_CLONE",
        "updated_at": datetime.now().isoformat(),
        "count": len(picks),
        "picks": picks,
    }
    path = "/var/autobot/TR_KRTR/value_clone_target.json"
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, "w", encoding="utf-8") as f:
        json.dump(out, f, ensure_ascii=False, indent=2)
    print(f"\n저장: {path}")
    for p in picks:
        print(f"  {p['name']}({p['code']}) PER={p['PER']} PBR={p['PBR']} "
              f"ROE={p['ROE_est']}% 배당={p['DIV_pct']}% 점수={p['value_score']}")
